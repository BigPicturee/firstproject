﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Drawing;

namespace tempServer
{
    public class Systems
    {
        public int[] room_num = new int[6]; //  방 활성화 여부 - 비활성화 = 0, 활성화 = 1
        public int[] viewers_num = new int[6];  // 방 접속자 수
        public int signal = 0;                  // 로비 = 0, 채팅 = 1, 이미지 = 2, 음성 = 3
        public List<Form> room = new List<Form>();   // 방 정보

        public byte[] ImageToByteArray(System.Drawing.Image image)
        {
            MemoryStream ms = new MemoryStream();
            image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            return ms.ToArray();
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = new Bitmap(Image.FromStream(ms));
            return returnImage;
        }

        public byte[] IntToByteArray(int intIn)
        {
            byte[] inttobyte = BitConverter.GetBytes(intIn);
            return inttobyte;
        }

        public int ByteArrayToInt(byte[] bytes)
        {
            int bytetoint = ((bytes[3] << 24) + (bytes[2] << 16) + (bytes[1] << 8) + (bytes[0]));
            return bytetoint;
        }

        public byte[] StringToByte(string str)
        {
            byte[] StrByte = Encoding.UTF8.GetBytes(str);
            return StrByte;
        }

        public string ByteToString(byte[] strByte)
        {
            string str = Encoding.Default.GetString(strByte);
            return str;
        }
    }
}
