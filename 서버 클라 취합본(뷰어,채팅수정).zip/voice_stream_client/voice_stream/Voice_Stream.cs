﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
///서버 및 쓰레드 사용 추가
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace voice_stream
{
    public partial class Voice_Stream : Form
    {

        ///////////////Clinet  소켓 생성

        public Systems systems = new Systems();
        public Viewers viewers = new Viewers();

        public Voice_Chat tempstrm = new Voice_Chat();

        public TcpClient clientSocket = new TcpClient();
        public NetworkStream stream = null;

        private string ServIP = "10.10.20.46";
        private int Port = 8081;


        public Voice_Stream()
        {
            CenterToScreen();
            InitializeComponent();

            new Thread(delegate ()
            {
                InitSocket();
            }).Start();
        }
        private void InitSocket()
        {
            try
            {
                clientSocket.Connect(IPAddress.Parse(ServIP), Port);
                stream = clientSocket.GetStream();

                Receive_Room_Data();
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        public void Receive_Room_Data()
        {
            List<byte[]> room_intbyteArray = new List<byte[]>();
            List<byte[]> viewer_intbyteArray = new List<byte[]>();

            for (int i = 0; i < 6; i++)
            {
                byte[] intbyte = new byte[1024];
                stream.Read(intbyte, 0, intbyte.Length);
                room_intbyteArray.Add(intbyte);
            }
            for (int i = 0; i < 6; i++)
            {
                byte[] _intbyte = new byte[1024];
                stream.Read(_intbyte, 0, _intbyte.Length);
                viewer_intbyteArray.Add(_intbyte);
            }
            for (int i = 0; i < 6; i++)
            {
                systems.room_num[i] = systems.ByteArrayToInt(room_intbyteArray[i]);
                systems.viewers_num[i] = systems.ByteArrayToInt(viewer_intbyteArray[i]);
            }

            Room_Refresh();
        }

        public void Room_Refresh()
        {
            List<Label> Room_Check = new List<Label>();
            List<Label> Room_St = new List<Label>();

            Room_Check.Add(Room_Check1);
            Room_Check.Add(Room_Check2);
            Room_Check.Add(Room_Check3);
            Room_Check.Add(Room_Check4);
            Room_Check.Add(Room_Check5);
            Room_Check.Add(Room_Check6);

            Room_St.Add(Room_St1);
            Room_St.Add(Room_St2);
            Room_St.Add(Room_St3);
            Room_St.Add(Room_St4);
            Room_St.Add(Room_St5);
            Room_St.Add(Room_St6);

            for (int i = 0; i < 6; i++)
            {
                Label_Text(Room_Check[i], $"{systems.viewers_num[i]}명 접속중");

                if (systems.room_num[i] == 1)
                    Label_Text(Room_St[i], "방송중");
            }
        }

        private void Room_Num1_Click(object sender, EventArgs e)
        {
            if (systems.room_num[0] == 1)
            {
                viewers.room_num = 1;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(1);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
            else
            {
                MessageBox.Show("생성된 방이 아닙니다.");
            }
        }

        private void Room_Num2_Click(object sender, EventArgs e)
        {
            if (systems.room_num[1] == 1)
            {
                viewers.room_num = 2;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(2);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
            else
            {
                MessageBox.Show("생성된 방이 아닙니다.");
            }
        }

        private void Room_Num3_Click(object sender, EventArgs e)
        {
            if (systems.room_num[2] == 1)
            {
                viewers.room_num = 3;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(3);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
            else
            {
                MessageBox.Show("생성된 방이 아닙니다.");
            }
        }

        private void Room_Num4_Click(object sender, EventArgs e)
        {
            if (systems.room_num[3] == 1)
            {
                viewers.room_num = 4;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(4);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
            else
            {
                MessageBox.Show("생성된 방이 아닙니다.");
            }
        }

        private void Room_Num5_Click(object sender, EventArgs e)
        {
            if (systems.room_num[4] == 1)
            {
                viewers.room_num = 5;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(5);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
            else
            {
                MessageBox.Show("생성된 방이 아닙니다.");
            }
        }

        private void Room_Num6_Click(object sender, EventArgs e)
        {
            if (systems.room_num[5] == 1)
            {
                viewers.room_num = 6;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(6);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
            else
            {
                MessageBox.Show("생성된 방이 아닙니다.");
            }
        }

        private void Voice_Close_Click(object sender, EventArgs e)
        {
            byte[] intbyte = new byte[1024];
            intbyte = systems.IntToByteArray(20);
            stream.Write(intbyte, 0, intbyte.Length);
            stream.Flush();

            if (clientSocket != null)
                clientSocket.Close();

            Close();
        }

        private void Make_Room_Click(object sender, EventArgs e)
        {
            int room = 0;

            for (int i = 0; i < 6; i++)
            {
                if (systems.room_num[i] == 0)
                {
                    room = i + 1;
                    break;
                }
            }
            if (room == 0)
            {
                MessageBox.Show("만들 수 있는 방이 없습니다.");
            }
            else
            {
                viewers.room_num = room;
                byte[] intbyte = new byte[1024];
                intbyte = systems.IntToByteArray(room + 6);                       // 방번호를 서버에 보내기
                stream.Write(intbyte, 0, intbyte.Length);
                stream.Flush();

                viewers.mode = 1;
                viewers.signal = 1;

                tempstrm.Owner = this;
                tempstrm.Show();
            }
        }      
        
        private void New_Check_Click(object sender, EventArgs e)
        {
            byte[] intbyte = new byte[1024];
            intbyte = systems.IntToByteArray(13);                       // 방번호를 서버에 보내기
            stream.Write(intbyte, 0, intbyte.Length);
            stream.Flush();

            Receive_Room_Data();
        }

        private void Label_Text(Label label, string text) //Server에 메시지 출력
        {
            //하나의 Form을 다른 thread에서 접근하게 될 경우에 기존의 Form과 충돌이 날 수 있다.
            //invoke를 사용하여 실행하려고 하는 메소드의 대리자를 실행
            if (label.InvokeRequired)
            {
                label.BeginInvoke(new MethodInvoker(delegate
                {
                    label.Text = text + Environment.NewLine;
                }));

            }
            else
                label.Text = text + Environment.NewLine;
        }
    }
}
