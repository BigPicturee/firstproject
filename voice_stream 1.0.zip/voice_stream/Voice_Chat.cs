﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//
using System.Threading;//
using System.Drawing.Imaging;//

using voice_stream;

namespace voice_stream
{
    public partial class Voice_Chat : Form
    {
        private static Bitmap bmpScreen;//
        private int mode = 0;//
        private Thread thread;//
        private MemoryStream ms;//
        private byte[] buf;//

        public Voice_Chat()
        {
            InitializeComponent();
            InitSetting();//
        }

        private void New1_Close_Click(object sender, EventArgs e)
        {
            Voice_Stream Voice_Form = (Voice_Stream)this.Owner;
            int St_King = 1;    //방송 스트리머
            if(St_King==1)  //방송 스트리머
            {
                Voice_Form.room_num[0] = 0;
            }
            else      //시청자
            {
                Voice_Form.num[0] -= 1;
            }
            Close();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitSetting()      //초기 설정
        {
            picMode.Image = Properties.Resources.Image_cursors;
            picMode.SizeMode = PictureBoxSizeMode.Zoom;
            picColor.BackColor = Color.Black;
            this.KeyPreview = true;

            //thread = new Thread(CaptureThread);
        }

        private void CaptureScreen()//그림모드: 컨트롤 캡쳐
        {
            bmpScreen = new Bitmap(600, 640);

            using (Graphics g = Graphics.FromImage(bmpScreen))
            {
                g.CopyFromScreen(this.PointToScreen(new Point(picCapture.Bounds.X + 1, picCapture.Bounds.Y + 1)), new Point(0, 0), bmpScreen.Size, CopyPixelOperation.SourceCopy);
                picCapture.Image = bmpScreen;
            }

            picCapture.BringToFront();
        }

        private void CaptureThread()     //송신 스레드
        {
            while (true)
            {
                try
                {
                    Bitmap bitmap = new Bitmap(picCapture.Image);
                    ms = new MemoryStream();

                    bitmap.Save(ms, ImageFormat.Bmp);
                    ms.Position = 0;
                    buf = ms.ToArray();

                    ms.Write(buf, 0, buf.Length);
                }

                catch (Exception e)
                {
                    MessageBox.Show(e.StackTrace);
                }

                Thread.Sleep(200);
            }
        }

        private void New1_File_Click(object sender, EventArgs e)//파일 불러오기
        {
            OpenFileDialog openFile = new OpenFileDialog();

            openFile.Filter = "모든 파일(*.*) | *.*|PDF (* .pdf) | *.pdf; |이미지 (* .jpg, * .bmp, * .png) | *.jpg; *.bmp; *.png; ";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (openFile.FileName.EndsWith(".pdf"))//PDF 2
                    {
                        pdfView.BringToFront();
                        pdfView.LoadFile(openFile.FileName);
                    }

                    else if (openFile.FileName.EndsWith(".txt"))//TXT 3         
                    {
                        RTB.BringToFront();
                        StreamReader objRead = new StreamReader(openFile.FileName);
                        RTB.Text = objRead.ReadToEnd();

                        objRead.Close();
                        objRead.Dispose();
                    }

                    else//Image(jpg, png...) 1
                    {
                        PIC.BringToFront();
                        PIC.Image = Image.FromFile(@openFile.FileName);
                        PIC.SizeMode = PictureBoxSizeMode.Zoom;
                    }

                    txtPath.Text = openFile.FileName;
                }

                catch
                {
                    MessageBox.Show("잘못된 파일 형식입니다.");
                }
            }
        }

        private Cursor GetImageCursor(Image image)      //커서 변경
        {
            int width = image.Width / 12;
            int height = image.Height / 12;

            Size resize = new Size(width, height);
            //
            Bitmap bitmap = new Bitmap(image, resize);
            Graphics graphics = Graphics.FromImage(bitmap);
            IntPtr handle = bitmap.GetHicon();
            Cursor cursor = new Cursor(handle);
            return cursor;
        }

        private void picCapture_MouseMove(object sender, MouseEventArgs e)//그리기모드(선 긋기)
        {
            if (e.Button == MouseButtons.Left && this.Cursor != Cursors.Default)
            {
                Point curPoint = picCapture.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));

                Pen p = new Pen(picColor.BackColor);
                p.Width = 4;

                Graphics g = Graphics.FromImage(picCapture.Image);
                g.DrawEllipse(p, curPoint.X, curPoint.Y, p.Width, p.Width);
                picCapture.Image = picCapture.Image;

                p.Dispose();
                g.Dispose();
            }
        }

        private void picColor_Click(object sender, EventArgs e)//펜 색상 변경
        {
            ChangeColor();
        }       

        private void picMode_Click(object sender, EventArgs e)//모드 변경
        {
            ChangeMode();
        }

        private void Voice_Chat_KeyDown(object sender, KeyEventArgs e)//(모드 변경)(단축키)
        {
            if (e.Control && e.KeyCode == (Keys.Q))
            {
                ChangeMode();
            }

            else if (e.Control && e.KeyCode == (Keys.W))
            {
                ChangeColor();
            }
        }

        private void ChangeColor()
        {
            ColorDialog colorlog = new ColorDialog();
            if (colorlog.ShowDialog() == DialogResult.OK)
            {
                picColor.BackColor = colorlog.Color;
            }
        }

        private void ChangeMode()
        {
            if (mode == 0)       //일반 -> 그리기
            {
                mode = 1;

                this.Cursor = GetImageCursor(Properties.Resources.Image_Pen);

                picMode.Image = Properties.Resources.Image_Pen;
                picMode.SizeMode = PictureBoxSizeMode.Zoom;

                CaptureScreen();
            }
            else if (mode == 1)      //그리기 -> 일반
            {
                mode = 0;

                picCapture.SendToBack();

                this.Cursor = Cursors.Default;

                picMode.Image = Properties.Resources.Image_cursors;
                picMode.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
