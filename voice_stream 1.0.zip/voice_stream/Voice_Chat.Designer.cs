﻿namespace voice_stream
{
    partial class Voice_Chat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Voice_Chat));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.textBox = new System.Windows.Forms.TextBox();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.Send_Message = new System.Windows.Forms.Button();
            this.New1_Close = new System.Windows.Forms.Button();
            this.New1_File = new System.Windows.Forms.Button();
            this.RTB = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pdfView = new AxAcroPDFLib.AxAcroPDF();
            this.PIC = new System.Windows.Forms.PictureBox();
            this.picCapture = new System.Windows.Forms.PictureBox();
            this.picMode = new System.Windows.Forms.PictureBox();
            this.picColor = new System.Windows.Forms.PictureBox();
            this.txtKey1 = new System.Windows.Forms.Label();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.txtKey2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pdfView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picColor)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(12, 424);
            this.textBox.MaximumSize = new System.Drawing.Size(460, 25);
            this.textBox.MinimumSize = new System.Drawing.Size(460, 25);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(460, 21);
            this.textBox.TabIndex = 1;
            // 
            // richTextBox
            // 
            this.richTextBox.Location = new System.Drawing.Point(12, 133);
            this.richTextBox.MaximumSize = new System.Drawing.Size(460, 280);
            this.richTextBox.MinimumSize = new System.Drawing.Size(460, 280);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(460, 280);
            this.richTextBox.TabIndex = 2;
            this.richTextBox.Text = "";
            // 
            // Send_Message
            // 
            this.Send_Message.Location = new System.Drawing.Point(12, 466);
            this.Send_Message.MaximumSize = new System.Drawing.Size(100, 30);
            this.Send_Message.MinimumSize = new System.Drawing.Size(100, 30);
            this.Send_Message.Name = "Send_Message";
            this.Send_Message.Size = new System.Drawing.Size(100, 30);
            this.Send_Message.TabIndex = 3;
            this.Send_Message.Text = "메시지 전송";
            this.Send_Message.UseVisualStyleBackColor = true;
            // 
            // New1_Close
            // 
            this.New1_Close.Location = new System.Drawing.Point(1018, 719);
            this.New1_Close.MaximumSize = new System.Drawing.Size(100, 30);
            this.New1_Close.MinimumSize = new System.Drawing.Size(100, 30);
            this.New1_Close.Name = "New1_Close";
            this.New1_Close.Size = new System.Drawing.Size(100, 30);
            this.New1_Close.TabIndex = 3;
            this.New1_Close.Text = "나가기";
            this.New1_Close.UseVisualStyleBackColor = true;
            this.New1_Close.Click += new System.EventHandler(this.New1_Close_Click);
            // 
            // New1_File
            // 
            this.New1_File.Location = new System.Drawing.Point(912, 719);
            this.New1_File.MaximumSize = new System.Drawing.Size(100, 30);
            this.New1_File.MinimumSize = new System.Drawing.Size(100, 30);
            this.New1_File.Name = "New1_File";
            this.New1_File.Size = new System.Drawing.Size(100, 30);
            this.New1_File.TabIndex = 3;
            this.New1_File.Text = "파일 전송";
            this.New1_File.UseVisualStyleBackColor = true;
            this.New1_File.Click += new System.EventHandler(this.New1_File_Click);
            // 
            // RTB
            // 
            this.RTB.Location = new System.Drawing.Point(522, 12);
            this.RTB.Name = "RTB";
            this.RTB.Size = new System.Drawing.Size(600, 640);
            this.RTB.TabIndex = 4;
            this.RTB.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "스트리머 사진";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(207, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(269, 38);
            this.button1.TabIndex = 6;
            this.button1.Text = "hide시켜서 스트리머만 누를수 있는 오디오";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(207, 57);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(269, 38);
            this.button2.TabIndex = 7;
            this.button2.Text = "폼만들어서 파일전송 선택할수잇는 시청자";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // pdfView
            // 
            this.pdfView.Enabled = true;
            this.pdfView.Location = new System.Drawing.Point(522, 12);
            this.pdfView.Name = "pdfView";
            this.pdfView.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfView.OcxState")));
            this.pdfView.Size = new System.Drawing.Size(600, 640);
            this.pdfView.TabIndex = 8;
            // 
            // PIC
            // 
            this.PIC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PIC.Location = new System.Drawing.Point(522, 12);
            this.PIC.Name = "PIC";
            this.PIC.Size = new System.Drawing.Size(600, 640);
            this.PIC.TabIndex = 9;
            this.PIC.TabStop = false;
            // 
            // picCapture
            // 
            this.picCapture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCapture.Location = new System.Drawing.Point(522, 12);
            this.picCapture.Name = "picCapture";
            this.picCapture.Size = new System.Drawing.Size(600, 640);
            this.picCapture.TabIndex = 10;
            this.picCapture.TabStop = false;
            this.picCapture.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picCapture_MouseMove);
            // 
            // picMode
            // 
            this.picMode.Location = new System.Drawing.Point(522, 658);
            this.picMode.Name = "picMode";
            this.picMode.Size = new System.Drawing.Size(26, 31);
            this.picMode.TabIndex = 11;
            this.picMode.TabStop = false;
            this.picMode.Click += new System.EventHandler(this.picMode_Click);
            // 
            // picColor
            // 
            this.picColor.Location = new System.Drawing.Point(578, 658);
            this.picColor.Name = "picColor";
            this.picColor.Size = new System.Drawing.Size(26, 31);
            this.picColor.TabIndex = 12;
            this.picColor.TabStop = false;
            this.picColor.Click += new System.EventHandler(this.picColor_Click);
            // 
            // txtKey1
            // 
            this.txtKey1.AutoSize = true;
            this.txtKey1.Location = new System.Drawing.Point(520, 692);
            this.txtKey1.Name = "txtKey1";
            this.txtKey1.Size = new System.Drawing.Size(39, 12);
            this.txtKey1.TabIndex = 13;
            this.txtKey1.Text = "Ctrl+Q";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(522, 719);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(380, 21);
            this.txtPath.TabIndex = 14;
            // 
            // txtKey2
            // 
            this.txtKey2.AutoSize = true;
            this.txtKey2.Location = new System.Drawing.Point(576, 692);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(40, 12);
            this.txtKey2.TabIndex = 15;
            this.txtKey2.Text = "Ctrl+W";
            // 
            // Voice_Chat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 761);
            this.Controls.Add(this.txtKey2);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.txtKey1);
            this.Controls.Add(this.picColor);
            this.Controls.Add(this.picMode);
            this.Controls.Add(this.picCapture);
            this.Controls.Add(this.PIC);
            this.Controls.Add(this.pdfView);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RTB);
            this.Controls.Add(this.New1_File);
            this.Controls.Add(this.New1_Close);
            this.Controls.Add(this.Send_Message);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.textBox);
            this.MaximumSize = new System.Drawing.Size(1150, 800);
            this.MinimumSize = new System.Drawing.Size(850, 500);
            this.Name = "Voice_Chat";
            this.Text = "Form2";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Voice_Chat_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pdfView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picColor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.Button Send_Message;
        private System.Windows.Forms.Button New1_Close;
        private System.Windows.Forms.Button New1_File;
        private System.Windows.Forms.RichTextBox RTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private AxAcroPDFLib.AxAcroPDF pdfView;
        private System.Windows.Forms.PictureBox PIC;
        private System.Windows.Forms.PictureBox picCapture;
        private System.Windows.Forms.PictureBox picMode;
        private System.Windows.Forms.PictureBox picColor;
        private System.Windows.Forms.Label txtKey1;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Label txtKey2;
    }
}