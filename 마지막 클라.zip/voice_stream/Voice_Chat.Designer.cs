﻿namespace voice_stream
{
    partial class Voice_Chat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Voice_Chat));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.textBox = new System.Windows.Forms.TextBox();
            this.Send_Message = new System.Windows.Forms.Button();
            this.New1_Close = new System.Windows.Forms.Button();
            this.New1_File = new System.Windows.Forms.Button();
            this.RTB = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pdfView = new AxAcroPDFLib.AxAcroPDF();
            this.PIC = new System.Windows.Forms.PictureBox();
            this.picCapture = new System.Windows.Forms.PictureBox();
            this.picMode = new System.Windows.Forms.PictureBox();
            this.picColor = new System.Windows.Forms.PictureBox();
            this.txtKey1 = new System.Windows.Forms.Label();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.txtKey2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.chkStreamer = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pdfView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picColor)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(10, 523);
            this.textBox.MaximumSize = new System.Drawing.Size(460, 25);
            this.textBox.MinimumSize = new System.Drawing.Size(460, 25);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(460, 25);
            this.textBox.TabIndex = 1;
            this.textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_KeyDown);
            // 
            // Send_Message
            // 
            this.Send_Message.Location = new System.Drawing.Point(10, 554);
            this.Send_Message.MaximumSize = new System.Drawing.Size(100, 30);
            this.Send_Message.MinimumSize = new System.Drawing.Size(100, 30);
            this.Send_Message.Name = "Send_Message";
            this.Send_Message.Size = new System.Drawing.Size(100, 30);
            this.Send_Message.TabIndex = 3;
            this.Send_Message.Text = "메시지 전송";
            this.Send_Message.UseVisualStyleBackColor = true;
            this.Send_Message.Click += new System.EventHandler(this.Send_Message_Click);
            // 
            // New1_Close
            // 
            this.New1_Close.Location = new System.Drawing.Point(1018, 719);
            this.New1_Close.MaximumSize = new System.Drawing.Size(100, 30);
            this.New1_Close.MinimumSize = new System.Drawing.Size(100, 30);
            this.New1_Close.Name = "New1_Close";
            this.New1_Close.Size = new System.Drawing.Size(100, 30);
            this.New1_Close.TabIndex = 3;
            this.New1_Close.Text = "나가기";
            this.New1_Close.UseVisualStyleBackColor = true;
            this.New1_Close.Click += new System.EventHandler(this.New1_Close_Click);
            // 
            // New1_File
            // 
            this.New1_File.Location = new System.Drawing.Point(912, 719);
            this.New1_File.MaximumSize = new System.Drawing.Size(100, 30);
            this.New1_File.MinimumSize = new System.Drawing.Size(100, 30);
            this.New1_File.Name = "New1_File";
            this.New1_File.Size = new System.Drawing.Size(100, 30);
            this.New1_File.TabIndex = 3;
            this.New1_File.Text = "파일 전송";
            this.New1_File.UseVisualStyleBackColor = true;
            this.New1_File.Click += new System.EventHandler(this.New1_File_Click);
            // 
            // RTB
            // 
            this.RTB.Location = new System.Drawing.Point(522, 12);
            this.RTB.Name = "RTB";
            this.RTB.Size = new System.Drawing.Size(600, 640);
            this.RTB.TabIndex = 4;
            this.RTB.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(299, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 40);
            this.button1.TabIndex = 6;
            this.button1.Text = "마이크 온";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(299, 64);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 40);
            this.button2.TabIndex = 7;
            this.button2.Text = "마이크 오프";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pdfView
            // 
            this.pdfView.Enabled = true;
            this.pdfView.Location = new System.Drawing.Point(522, 12);
            this.pdfView.Name = "pdfView";
            this.pdfView.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfView.OcxState")));
            this.pdfView.Size = new System.Drawing.Size(600, 640);
            this.pdfView.TabIndex = 8;
            // 
            // PIC
            // 
            this.PIC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PIC.Location = new System.Drawing.Point(522, 12);
            this.PIC.Name = "PIC";
            this.PIC.Size = new System.Drawing.Size(600, 640);
            this.PIC.TabIndex = 9;
            this.PIC.TabStop = false;
            // 
            // picCapture
            // 
            this.picCapture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCapture.Location = new System.Drawing.Point(522, 12);
            this.picCapture.Name = "picCapture";
            this.picCapture.Size = new System.Drawing.Size(600, 640);
            this.picCapture.TabIndex = 10;
            this.picCapture.TabStop = false;
            this.picCapture.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picCapture_MouseMove);
            // 
            // picMode
            // 
            this.picMode.Location = new System.Drawing.Point(522, 658);
            this.picMode.Name = "picMode";
            this.picMode.Size = new System.Drawing.Size(26, 31);
            this.picMode.TabIndex = 11;
            this.picMode.TabStop = false;
            this.picMode.Click += new System.EventHandler(this.picMode_Click);
            // 
            // picColor
            // 
            this.picColor.Location = new System.Drawing.Point(578, 658);
            this.picColor.Name = "picColor";
            this.picColor.Size = new System.Drawing.Size(26, 31);
            this.picColor.TabIndex = 12;
            this.picColor.TabStop = false;
            this.picColor.Click += new System.EventHandler(this.picColor_Click);
            // 
            // txtKey1
            // 
            this.txtKey1.AutoSize = true;
            this.txtKey1.Location = new System.Drawing.Point(520, 692);
            this.txtKey1.Name = "txtKey1";
            this.txtKey1.Size = new System.Drawing.Size(39, 12);
            this.txtKey1.TabIndex = 13;
            this.txtKey1.Text = "Ctrl+Q";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(522, 719);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(380, 21);
            this.txtPath.TabIndex = 14;
            // 
            // txtKey2
            // 
            this.txtKey2.AutoSize = true;
            this.txtKey2.Location = new System.Drawing.Point(576, 692);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(40, 12);
            this.txtKey2.TabIndex = 15;
            this.txtKey2.Text = "Ctrl+W";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(458, 489);
            this.textBox1.TabIndex = 16;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // chkStreamer
            // 
            this.chkStreamer.AutoSize = true;
            this.chkStreamer.Location = new System.Drawing.Point(6, 31);
            this.chkStreamer.Name = "chkStreamer";
            this.chkStreamer.Size = new System.Drawing.Size(75, 16);
            this.chkStreamer.TabIndex = 17;
            this.chkStreamer.Text = "Streamer";
            this.chkStreamer.UseVisualStyleBackColor = true;
            this.chkStreamer.CheckedChanged += new System.EventHandler(this.chkStreamer_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkStreamer);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Location = new System.Drawing.Point(12, 612);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 128);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "마이크 상태 : ";
            // 
            // Voice_Chat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 761);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtKey2);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.txtKey1);
            this.Controls.Add(this.picColor);
            this.Controls.Add(this.picMode);
            this.Controls.Add(this.picCapture);
            this.Controls.Add(this.PIC);
            this.Controls.Add(this.pdfView);
            this.Controls.Add(this.RTB);
            this.Controls.Add(this.New1_File);
            this.Controls.Add(this.New1_Close);
            this.Controls.Add(this.Send_Message);
            this.Controls.Add(this.textBox);
            this.MaximumSize = new System.Drawing.Size(1150, 800);
            this.MinimumSize = new System.Drawing.Size(850, 500);
            this.Name = "Voice_Chat";
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Voice_Chat_FormClosing);
            this.Load += new System.EventHandler(this.Voice_Chat_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Voice_Chat_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pdfView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picColor)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button Send_Message;
        private System.Windows.Forms.Button New1_Close;
        private System.Windows.Forms.Button New1_File;
        private System.Windows.Forms.RichTextBox RTB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private AxAcroPDFLib.AxAcroPDF pdfView;
        private System.Windows.Forms.PictureBox PIC;
        private System.Windows.Forms.PictureBox picCapture;
        private System.Windows.Forms.PictureBox picMode;
        private System.Windows.Forms.PictureBox picColor;
        private System.Windows.Forms.Label txtKey1;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Label txtKey2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox chkStreamer;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}