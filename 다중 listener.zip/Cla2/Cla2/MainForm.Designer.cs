﻿namespace Cla2
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.labelIP = new System.Windows.Forms.Label();
            this.picCapture = new System.Windows.Forms.PictureBox();
            this.RTB = new System.Windows.Forms.RichTextBox();
            this.PIC = new System.Windows.Forms.PictureBox();
            this.pdfView = new AxAcroPDFLib.AxAcroPDF();
            this.picMode = new System.Windows.Forms.PictureBox();
            this.txtKey = new System.Windows.Forms.Label();
            this.picColor = new System.Windows.Forms.PictureBox();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.txtKey2 = new System.Windows.Forms.Label();
            this.txtTimeLine = new System.Windows.Forms.TextBox();
            this.Chatting = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtSend = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pdfView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picColor)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(12, 71);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(100, 23);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(12, 34);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(238, 21);
            this.txtIP.TabIndex = 2;
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.Location = new System.Drawing.Point(12, 9);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(44, 12);
            this.labelIP.TabIndex = 3;
            this.labelIP.Text = "서버 IP";
            // 
            // picCapture
            // 
            this.picCapture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCapture.Location = new System.Drawing.Point(272, 9);
            this.picCapture.Name = "picCapture";
            this.picCapture.Size = new System.Drawing.Size(600, 640);
            this.picCapture.TabIndex = 9;
            this.picCapture.TabStop = false;
            this.picCapture.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picCapture_MouseMove);
            // 
            // RTB
            // 
            this.RTB.Location = new System.Drawing.Point(272, 9);
            this.RTB.Name = "RTB";
            this.RTB.Size = new System.Drawing.Size(600, 640);
            this.RTB.TabIndex = 11;
            this.RTB.Text = "";
            // 
            // PIC
            // 
            this.PIC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PIC.Location = new System.Drawing.Point(272, 9);
            this.PIC.Name = "PIC";
            this.PIC.Size = new System.Drawing.Size(600, 640);
            this.PIC.TabIndex = 12;
            this.PIC.TabStop = false;
            // 
            // pdfView
            // 
            this.pdfView.Enabled = true;
            this.pdfView.Location = new System.Drawing.Point(272, 9);
            this.pdfView.Name = "pdfView";
            this.pdfView.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pdfView.OcxState")));
            this.pdfView.Size = new System.Drawing.Size(600, 640);
            this.pdfView.TabIndex = 13;
            // 
            // picMode
            // 
            this.picMode.Location = new System.Drawing.Point(14, 547);
            this.picMode.Name = "picMode";
            this.picMode.Size = new System.Drawing.Size(70, 50);
            this.picMode.TabIndex = 14;
            this.picMode.TabStop = false;
            this.picMode.Click += new System.EventHandler(this.picMode_Click);
            // 
            // txtKey
            // 
            this.txtKey.AutoSize = true;
            this.txtKey.Location = new System.Drawing.Point(25, 608);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(47, 12);
            this.txtKey.TabIndex = 15;
            this.txtKey.Text = "Ctrl + Q";
            // 
            // picColor
            // 
            this.picColor.Location = new System.Drawing.Point(113, 547);
            this.picColor.Name = "picColor";
            this.picColor.Size = new System.Drawing.Size(70, 50);
            this.picColor.TabIndex = 16;
            this.picColor.TabStop = false;
            this.picColor.Click += new System.EventHandler(this.picColor_Click);
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.Location = new System.Drawing.Point(231, 626);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(35, 23);
            this.btnOpenFile.TabIndex = 17;
            this.btnOpenFile.Text = "...";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(12, 626);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(213, 21);
            this.txtPath.TabIndex = 18;
            // 
            // txtKey2
            // 
            this.txtKey2.AutoSize = true;
            this.txtKey2.Location = new System.Drawing.Point(125, 608);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(48, 12);
            this.txtKey2.TabIndex = 19;
            this.txtKey2.Text = "Ctrl + W";
            // 
            // txtTimeLine
            // 
            this.txtTimeLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimeLine.Location = new System.Drawing.Point(10, 131);
            this.txtTimeLine.Multiline = true;
            this.txtTimeLine.Name = "txtTimeLine";
            this.txtTimeLine.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTimeLine.Size = new System.Drawing.Size(240, 392);
            this.txtTimeLine.TabIndex = 20;
            this.txtTimeLine.TextChanged += new System.EventHandler(this.txtTimeLine_TextChanged);
            // 
            // Chatting
            // 
            this.Chatting.Location = new System.Drawing.Point(878, 9);
            this.Chatting.Multiline = true;
            this.Chatting.Name = "Chatting";
            this.Chatting.Size = new System.Drawing.Size(266, 605);
            this.Chatting.TabIndex = 21;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(1105, 624);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(48, 23);
            this.btnSend.TabIndex = 23;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtSend
            // 
            this.txtSend.Location = new System.Drawing.Point(878, 626);
            this.txtSend.Name = "txtSend";
            this.txtSend.Size = new System.Drawing.Size(217, 21);
            this.txtSend.TabIndex = 24;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1156, 661);
            this.Controls.Add(this.txtSend);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.Chatting);
            this.Controls.Add(this.txtTimeLine);
            this.Controls.Add(this.txtKey2);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.btnOpenFile);
            this.Controls.Add(this.picColor);
            this.Controls.Add(this.txtKey);
            this.Controls.Add(this.picMode);
            this.Controls.Add(this.pdfView);
            this.Controls.Add(this.PIC);
            this.Controls.Add(this.RTB);
            this.Controls.Add(this.picCapture);
            this.Controls.Add(this.labelIP);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.btnConnect);
            this.Name = "MainForm";
            this.Text = "Client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pdfView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picColor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.PictureBox picCapture;
        private System.Windows.Forms.RichTextBox RTB;
        private System.Windows.Forms.PictureBox PIC;
        private AxAcroPDFLib.AxAcroPDF pdfView;
        private System.Windows.Forms.PictureBox picMode;
        private System.Windows.Forms.Label txtKey;
        private System.Windows.Forms.PictureBox picColor;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Label txtKey2;
        private System.Windows.Forms.TextBox txtTimeLine;
        private System.Windows.Forms.TextBox Chatting;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtSend;
    }
}

