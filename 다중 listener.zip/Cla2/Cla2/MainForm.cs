﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;

using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Cla2
{
    public partial class MainForm : Form
    {
        //뷰어 변수
        private int mode = 0;
        private static Bitmap bmpScreen;
        //통신 변수
        private TcpClient tcpClient = null;
        private TcpClient tcpClient2 = null;
        private NetworkStream stream = null;
        private NetworkStream stream2 = null;

        private int ServPort = 8081;
        private int ServPort2 = 8082;
        private string ServIP = "10.10.20.46";

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(stream != null)
                stream.Close();         //stream을 닫으면 tcpclient도 같이 닫힘
            //tcpClient.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)      //메인 폼 로드
        {
            picMode.Image = Properties.Resources.Image_cursors;
            picMode.SizeMode = PictureBoxSizeMode.Zoom;
            picColor.BackColor = Color.Black;
            this.KeyPreview = true;     //키보드 이벤트 활성화
        }

        private void btnConnect_Click(object sender, EventArgs e)       //서버와 연결
        {
            tcpClient = new TcpClient();
            tcpClient.Connect(ServIP, ServPort);        //서버와 연결되기 전까지 블로킹상태

            tcpClient2 = new TcpClient();
            tcpClient2.Connect(ServIP, ServPort2);        //서버와 연결되기 전까지 블로킹상태

            if (tcpClient.Connected)
            {
                txtIP.Text = ServIP;
                txtTimeLine.Text += "뷰 서버 연결 성공." + Environment.NewLine;        //textBox 업데이트
                stream = tcpClient.GetStream();
                while(true)
                {
                    CaptureScreen();

                    byte[] buf = new byte[1024];
                    buf = ImageToByteArray(picCapture.Image);
                    stream.Write(buf, 0, buf.Length);
                    //stream.Flush();

                    txtTimeLine.Text += "서버로 보냄." + Environment.NewLine;        //textBox 업데이트
                    Delay(20);   //통신 딜레이
                }
            }
        }

        private byte[] ImageToByteArray(System.Drawing.Image image)      //이미지=>배열 변환
        {
            MemoryStream ms = new MemoryStream();
            image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);     
            return ms.ToArray();
        }

        private void CaptureScreen()     //뷰어 캡쳐
        {
            bmpScreen = new Bitmap(600, 640);       //뷰어 크기

            using (Graphics g = Graphics.FromImage(bmpScreen))
            {
                g.CopyFromScreen(this.PointToScreen(new Point(picCapture.Bounds.X + 1, picCapture.Bounds.Y + 1)), new Point(0, 0), bmpScreen.Size, CopyPixelOperation.SourceCopy);
                picCapture.Image = bmpScreen;
            }
        }

        private void DrawMode()      //그리기 모드
        {
            CaptureScreen();
            picCapture.BringToFront();
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)        //단축키(커서&펜 변경) **PDF뷰어 상태에서는 안먹힘
        {
            if (e.Control && e.KeyCode == (Keys.Q))
            {
                ChangeMode();
            }

            if (e.Control && e.KeyCode == (Keys.W))
            {
                ColorDialog colorlog = new ColorDialog();
                if (colorlog.ShowDialog() == DialogResult.OK)
                {
                    picColor.BackColor = colorlog.Color;
                }
            }
        }

        private void picMode_Click(object sender, EventArgs e)      //모드 변경
        {
            ChangeMode();
        }

        private void ChangeMode()
        {
            if (mode == 0)       //일반모드 -> 그리기모드
            {
                mode = 1;

                this.Cursor = GetImageCursor(Properties.Resources.Image_Pen);

                picMode.Image = Properties.Resources.Image_Pen;
                picMode.SizeMode = PictureBoxSizeMode.Zoom;

                DrawMode();
            }
            else if (mode == 1)      //그리기모드 -> 일반모드
            {
                mode = 0;

                picCapture.SendToBack();

                this.Cursor = Cursors.Default;

                picMode.Image = Properties.Resources.Image_cursors;
                picMode.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }       //모드 변경

        private Cursor GetImageCursor(Image image)      //커서 변경
        {
            int width = image.Width / 12;
            int height = image.Height / 12;

            Size resize = new Size(width, height);
            
            Bitmap bitmap = new Bitmap(image, resize);
            Graphics graphics = Graphics.FromImage(bitmap);
            IntPtr handle = bitmap.GetHicon();
            Cursor cursor = new Cursor(handle);
            return cursor;
        }

        private void picColor_Click(object sender, EventArgs e)     //펜 색상 변경
        {
            ColorDialog colorlog = new ColorDialog();
            if (colorlog.ShowDialog() == DialogResult.OK)
            {
                picColor.BackColor = colorlog.Color;
            }
        }

        private void btnOpenFile_Click(object sender, EventArgs e)      //파일 불러오기
        {
            OpenFile();
        }

        private void OpenFile()
        {
            OpenFileDialog openFile = new OpenFileDialog();

            openFile.Filter = "모든 파일(*.*) | *.*|PDF (* .pdf) | *.pdf; |이미지 (* .jpg, * .bmp, * .png) | *.jpg; *.bmp; *.png; ";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (openFile.FileName.EndsWith(".pdf"))     //PDF 
                    {
                        pdfView.BringToFront();
                        pdfView.LoadFile(openFile.FileName);
                    }

                    else if (openFile.FileName.EndsWith(".txt"))    //TXT        
                    {
                        RTB.BringToFront();
                        StreamReader objRead = new StreamReader(openFile.FileName);
                        RTB.Text = objRead.ReadToEnd();

                        objRead.Close();
                        objRead.Dispose();
                    }

                    else    // Image
                    {
                        PIC.BringToFront();
                        PIC.Image = Image.FromFile(@openFile.FileName);
                        PIC.SizeMode = PictureBoxSizeMode.Zoom;
                    }

                    txtPath.Text = openFile.FileName;
                }

                catch       //지원하지 않는 파일 형식
                {
                    MessageBox.Show("잘못된 파일 형식입니다.");
                }
            }
        }

        private void picCapture_MouseMove(object sender, MouseEventArgs e)      //그리기
        {
            if (e.Button == MouseButtons.Left && this.Cursor != Cursors.Default)
            {
                Point curPoint = picCapture.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));

                Pen p = new Pen(picColor.BackColor);
                p.Width = 6;

                Graphics g = Graphics.FromImage(picCapture.Image);
                g.DrawEllipse(p, curPoint.X, curPoint.Y, p.Width, p.Width);
                picCapture.Image = picCapture.Image;

                p.Dispose();
                g.Dispose();
            }
        }

        private static DateTime Delay(int MS)       //딜레이 
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);
            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }
            return DateTime.Now;
        }

        private void txtTimeLine_TextChanged(object sender, EventArgs e)        //텍스트 박스 정보 업데이트 될 때마다 커서 지점, 스크롤바 당기기
        {
            this.txtTimeLine.SelectionStart = txtTimeLine.Text.Length;
            this.txtTimeLine.ScrollToCaret();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            this.ActiveControl = txtSend;
            byte[] buffer = Encoding.Unicode.GetBytes(txtSend.Text + "$");
            stream2 = tcpClient2.GetStream();
        
            stream2.Write(buffer, 0, buffer.Length);
            stream2.Flush();
            txtSend.Text = "";
            //textBox2.Focus();
        }
    }
}
