﻿namespace Sev2
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelIP = new System.Windows.Forms.Label();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.btnAccept = new System.Windows.Forms.Button();
            this.txtClient = new System.Windows.Forms.TextBox();
            this.picScreen = new System.Windows.Forms.PictureBox();
            this.txtTimeLine = new System.Windows.Forms.TextBox();
            this.txtChat = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picScreen)).BeginInit();
            this.SuspendLayout();
            // 
            // labelIP
            // 
            this.labelIP.AutoSize = true;
            this.labelIP.Location = new System.Drawing.Point(13, 12);
            this.labelIP.Name = "labelIP";
            this.labelIP.Size = new System.Drawing.Size(44, 12);
            this.labelIP.TabIndex = 0;
            this.labelIP.Text = "서버 IP";
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(12, 37);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(240, 21);
            this.txtIP.TabIndex = 1;
            // 
            // btnAccept
            // 
            this.btnAccept.Location = new System.Drawing.Point(12, 64);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(100, 23);
            this.btnAccept.TabIndex = 2;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // txtClient
            // 
            this.txtClient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClient.Location = new System.Drawing.Point(9, 110);
            this.txtClient.Multiline = true;
            this.txtClient.Name = "txtClient";
            this.txtClient.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtClient.Size = new System.Drawing.Size(240, 125);
            this.txtClient.TabIndex = 3;
            this.txtClient.TextChanged += new System.EventHandler(this.txtClient_TextChanged);
            // 
            // picScreen
            // 
            this.picScreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picScreen.Location = new System.Drawing.Point(271, 12);
            this.picScreen.Name = "picScreen";
            this.picScreen.Size = new System.Drawing.Size(600, 640);
            this.picScreen.TabIndex = 4;
            this.picScreen.TabStop = false;
            // 
            // txtTimeLine
            // 
            this.txtTimeLine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimeLine.Location = new System.Drawing.Point(9, 257);
            this.txtTimeLine.Multiline = true;
            this.txtTimeLine.Name = "txtTimeLine";
            this.txtTimeLine.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTimeLine.Size = new System.Drawing.Size(240, 392);
            this.txtTimeLine.TabIndex = 5;
            this.txtTimeLine.TextChanged += new System.EventHandler(this.txtTimeLine_TextChanged);
            // 
            // txtChat
            // 
            this.txtChat.Location = new System.Drawing.Point(877, 12);
            this.txtChat.Multiline = true;
            this.txtChat.Name = "txtChat";
            this.txtChat.Size = new System.Drawing.Size(403, 639);
            this.txtChat.TabIndex = 6;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 661);
            this.Controls.Add(this.txtChat);
            this.Controls.Add(this.txtTimeLine);
            this.Controls.Add(this.picScreen);
            this.Controls.Add(this.txtClient);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.labelIP);
            this.Name = "MainForm";
            this.Text = "Server";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picScreen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelIP;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.TextBox txtClient;
        private System.Windows.Forms.PictureBox picScreen;
        private System.Windows.Forms.TextBox txtTimeLine;
        private System.Windows.Forms.TextBox txtChat;
    }
}

