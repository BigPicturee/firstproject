﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Sev2
{
    public partial class MainForm : Form
    {
        TcpListener tcpListener = null;     //클라이언트 연결 요청받을 객체(뷰어)
        TcpListener tcpListener2 = null;     //클라이언트 연결 요청받을 객체(채팅)

        string IP = "10.10.20.46";

        int viewPort = 8081;//뷰어포트
        int chatPort = 8082;//채팅포트

        object lockthis = new object();

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)      //메인 폼 로드
        {
            tcpListener = new TcpListener(IPAddress.Parse(IP), viewPort);        //IP 10.10.20.46, 포트 8081      뷰어
            tcpListener.Start();        //연결요청 수신대기

            tcpListener2 = new TcpListener(IPAddress.Parse(IP), chatPort);        //IP 10.10.20.46, 포트 8082     채팅
            tcpListener2.Start();        //연결요청 수신대기

            this.txtIP.Text = IP;
            //IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());     //호스트 주소

            //for(int i=0; i<host.AddressList.Length; i++)
            //{
            //    if(host.AddressList[i].AddressFamily == AddressFamily.InterNetwork) //IPV4
            //    {
            //        txtIP.Text = host.AddressList[i].ToString();    //텍스트박스에 서버 ip 입력
            //        break;
            //    }
            //}

            //SendToCla = new SendToClient_dele(WriteToClient);       //델리게이트 내부함수 할당
            //SendToCla = WriteToClient;            위 코드와 같음
        }

        private void btnAccept_Click(object sender, EventArgs e)        //클라이언트 연결 요청 대기 스레드
        {
            btnAccept.Enabled = false; 
            Thread thd = new Thread(new ThreadStart(AcceptClient));     //파라미터 없는 스레드 
            thd.IsBackground = true;        //메인스레드가 종료되면 thd 스레드도 종료
            thd.Start();
        }

        private void AcceptClient()     //클라이언트 연결요청 대기(thread)
        {
            //클라이언트와 연결요청시, 리턴값으로 tcpclient의 객체를 반환받는다.
            //클라이언트와 연결 성공전까지 블로킹 상태
            TcpClient tcpClient = tcpListener.AcceptTcpClient();        //연결요청 수락  뷰어
            TcpClient tcpClient2 = tcpListener2.AcceptTcpClient();        //연결요청 수락  채팅

            if (tcpClient.Connected)     //소켓에 클라이언트가 연결되었다면
            {
                string clientIP = ((IPEndPoint)tcpClient.Client.RemoteEndPoint).Address.ToString();     //클라이언트 IP받아오기
                if(txtClient.InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate ()
                    {
                        txtClient.Text += clientIP + " 에서 접속" + Environment.NewLine;        //textBox 업데이트
                    }));
                }
                else
                {
                    txtClient.Text += clientIP + " 에서 접속" + Environment.NewLine;        //textBox 업데이트
                }
            }
            
            Thread Pro = new Thread(new ParameterizedThreadStart(ViewSendReceive));     //뷰어 송수신 스레드
            Pro.IsBackground = true;
            Pro.Start(tcpClient);

            Thread Pro2 = new Thread(new ParameterizedThreadStart(ChatSendReceive));        //채팅 송수신 스레드
            Pro2.IsBackground = true;
            Pro2.Start(tcpClient2);

            //Serv serv = new Serv(tcpClient, this.SendToCla);
            
            //Thread Pro = new Thread(new ThreadStart(serv.SendReceive));
            //Pro.IsBackground = true;       //메인스레드가 종료되면 Pro 스레드도 종료
            //Pro.Start();
        }

        private void ViewSendReceive(object _client)        //연결 후 뷰어 통신 스레드
        {
            TcpClient client = (TcpClient)_client;
            NetworkStream stream = null;
            stream = client.GetStream();

            byte[] buf = new byte[1024];
            byte[] buffer = new byte[1024];
            int nbytes;

            try
            {
                while(true)
                {
                    MemoryStream memory = new MemoryStream();

                    while(true)
                    {
                        nbytes = stream.Read(buf, 0, buf.Length);
                        memory.Write(buf, 0, nbytes);
                        if (stream.DataAvailable == false) break;
                    }

                    buffer = memory.ToArray();

                    if (picScreen.InvokeRequired)
                    {
                        this.Invoke(new MethodInvoker(delegate ()
                        {
                            picScreen.Image = byteArrayToImage(buffer);
                            txtTimeLine.Text += "사진이 전송되었습니다" + Environment.NewLine;        //textBox 업데이트

                        }));
                    }
                    else
                    {
                        picScreen.Image = byteArrayToImage(buffer);
                        txtTimeLine.Text += "사진이 전송되었습니다" + Environment.NewLine;        //textBox 업데이트
                    }
                    memory.Dispose();
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void ChatSendReceive(object _client)
        {
            TcpClient client = (TcpClient)_client;
            NetworkStream stream = null;
            stream = client.GetStream();

            int bytes = 0;
            string msg = string.Empty;
            byte[] buffer = new byte[1024];


            try
            {
                while (true)
                {
                    bytes = stream.Read(buffer, 0, buffer.Length);
                    msg = Encoding.Unicode.GetString(buffer, 0, bytes);
                    msg = msg.Substring(0, msg.IndexOf("$"));

                    if(txtChat.InvokeRequired)
                    {
                        this.Invoke(new MethodInvoker(delegate ()
                        {
                            txtChat.Text += msg + Environment.NewLine;        //textBox 업데이트
                        }));
                    }
                    else
                    {
                        txtChat.Text +=  msg + Environment.NewLine;        //textBox 업데이트
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }       //연결 후 채팅 통신 스레드

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)        //메인 폼 닫힘
        {
            if (tcpListener != null) tcpListener.Stop();
            if (tcpListener2 != null) tcpListener2.Stop();
        }

        private Image byteArrayToImage(byte[] byteArrayIn)       //바이트=>이미지 (lock : 한번에 한 스레드씩 접근)
        {
            lock(lockthis)
            {
                MemoryStream ms = new MemoryStream(byteArrayIn);
                Image returnImage = new Bitmap(Image.FromStream(ms));
                return returnImage;
            }
        }
        
        private static DateTime Delay(int MS)       //딜레이
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);
            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }
            return DateTime.Now;
        }

        private void txtClient_TextChanged(object sender, EventArgs e)      //텍스트 박스 정보 업데이트 될 때마다 커서 지점, 스크롤바 당기기
        {
            this.txtClient.SelectionStart = txtTimeLine.Text.Length;
            this.txtClient.ScrollToCaret();
        }

        private void txtTimeLine_TextChanged(object sender, EventArgs e)        //텍스트 박스 정보 업데이트 될 때마다 커서 지점, 스크롤바 당기기
        {
            this.txtTimeLine.SelectionStart = txtTimeLine.Text.Length;
            this.txtTimeLine.ScrollToCaret();
        }
    }
}
