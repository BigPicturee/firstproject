﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Diagnostics;

namespace tempServer
{
    public partial class tempServer : Form
    {
        TcpListener server = null;

        static int count = 0;

        public Systems systems = new Systems();
        public Viewers[] viewers = new Viewers[50];

        public TcpClient[] clientSocket = new TcpClient[50];

        private string ServIP = "10.10.20.46";
        private int Port = 8081;

        Thread[] room_thread = new Thread[50];

        private Mutex mutx = new Mutex();
        object lockthis = new object();///

        public tempServer()
        {
            InitializeComponent();

            viewers = new Viewers[50];
            clientSocket = new TcpClient[50];
            for (int i = 0; i < 50; i++)
            {
                viewers[i] = new Viewers();
                clientSocket[i] = new TcpClient();
            }

            for (int i = 0; i < 50; i++)
            {
                viewers[i].name = $"User-{i + 1}";
            }

            Thread t = new Thread(InitSocket);  // 쓰레드 생성
            t.IsBackground = true;
            t.Start();      // 쓰레드 실행
        }

        private void InitSocket()       // 클라이언트 연결
        {
            RichTextBox_Text(">> Server Started" + Environment.NewLine);
            server = new TcpListener(IPAddress.Parse(ServIP), Port);        // IP와 포트로 연결
            server.Start();     // 서버 시작

            while (true)
            {
                try
                {
                    mutx.WaitOne();
                    clientSocket[count] = server.AcceptTcpClient();            // 클라이언트과 연결
                    mutx.ReleaseMutex();

                    if (clientSocket[count].Connected == true)     //소켓에 클라이언트가 연결되었다면
                    {
                        string clientIP = ((IPEndPoint)clientSocket[count].Client.RemoteEndPoint).Address.ToString();     //클라이언트 IP받아오기
                        RichTextBox_Text(clientIP + " 에서 접속" + Environment.NewLine);

                        NetworkStream stream = clientSocket[count].GetStream();         // stream 연결

                        room_thread[count] = new Thread(() => Room_Choice(count, stream));  // 쓰레드 생성

                        room_thread[count].IsBackground = true;
                        room_thread[count].Start();                                                 // 쓰레드 시작

                        Delay(500);

                        count++;                    // 클라이언트 개수        count++;
                    }
                }
                catch (SocketException se)
                {
                    Trace.WriteLine(string.Format("InitSocket - SocketException : {0}", se.Message));
                    break;
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(string.Format("InitSocket - Exception : {0}", ex.Message));
                    break;
                }
            }
            for(int i = 0; i < count; i++)
                clientSocket[i].Close();        // 클라이언트 소켓 닫기

            server.Stop();
        }

        private void Room_Data_To_ByteArray(NetworkStream stream)
        {
            List<byte[]> room_intbyteArray = new List<byte[]>();
            List<byte[]> viewer_intbyteArray = new List<byte[]>();

            for (int i = 0; i < 6; i++)
            {
                byte[] intbyteArray = new byte[1024];
                intbyteArray = systems.IntToByteArray(systems.room_num[i]);
                room_intbyteArray.Add(intbyteArray);

                byte[] _intbyteArray = new byte[1024];
                _intbyteArray = systems.IntToByteArray(systems.viewers_num[i]);
                viewer_intbyteArray.Add(_intbyteArray);
            }
            Send_Room_Data(room_intbyteArray, viewer_intbyteArray, stream);
        }

        private void Send_Room_Data(List<byte[]> bytearray, List<byte[]> _bytearray, NetworkStream stream)
        {
            for (int i = 0; i < 6; i++)
            {
                stream.Write(bytearray[i], 0, bytearray[i].Length);
                int num = systems.ByteArrayToInt(bytearray[i]);
                System.Console.WriteLine($"{i + 1}번방 : {num}");
                Delay(100);
            }
            for (int i = 0; i < 6; i++)
            {
                stream.Write(_bytearray[i], 0, _bytearray[i].Length);
                int _num = systems.ByteArrayToInt(_bytearray[i]);
                System.Console.WriteLine($"{i + 1}번방 인원 : {_num}");
                Delay(100);
            }
            System.Console.WriteLine();
        }

        private void Room_Choice(int cnt, NetworkStream stream)         // 방 고를 때 쓰는 쓰레드
        {
            Room_Data_To_ByteArray(stream);

            while (true)
            {
                try
                {
                    if (viewers[cnt].room_num == 0)
                    {
                        //MessageBox.Show($"{viewers[cnt].room_num}");
                        byte[] intbyte = new byte[1024];
                        stream.Read(intbyte, 0, intbyte.Length);
                        viewers[cnt].room_num = systems.ByteArrayToInt(intbyte);        // 방 번호 받아오는 Read
                                                                                        //MessageBox.Show($"{viewers[cnt].room_num}");
                        if (viewers[cnt].room_num >= 1 && viewers[cnt].room_num <= 6)        // 방번호가 1 ~ 6이면 방들어가기 7 ~ 12면 방만들기 0이면 새로고침 나머지 종료
                        {
                            Thread msg_thread = new Thread(() => Send_Receive_Data(cnt, stream));
                            msg_thread.IsBackground = true;
                            systems.viewers_num[viewers[cnt].room_num - 1] += 1;
                            viewers[cnt].mode = 0;
                            viewers[cnt].signal = 1;
                            RichTextBox_Text($"{viewers[cnt].name}님이 {viewers[cnt].room_num}번방에 들어갔습니다.\n");
                            
                            msg_thread.Start();
                        }
                        else if (viewers[cnt].room_num >= 7 && viewers[cnt].room_num <= 12)
                        {
                            Thread msg_thread = new Thread(() => Send_Receive_Data(cnt, stream));
                            msg_thread.IsBackground = true;
                            viewers[cnt].room_num -= 6;
                            systems.viewers_num[viewers[cnt].room_num - 1] += 1;
                            systems.room_num[viewers[cnt].room_num - 1] = 1;
                            viewers[cnt].mode = 1;
                            viewers[cnt].signal = 1;
                            RichTextBox_Text($"{viewers[cnt].name}님이 {viewers[cnt].room_num}번방을 만들었습니다.\n");
                            msg_thread.Start();
                        }
                        else if (viewers[cnt].room_num == 0)
                        {
                            Thread room_data = new Thread(() => Room_Data_To_ByteArray(stream));
                            room_data.IsBackground = true;
                            room_data.Start();
                        }
                        else
                        {
                            RichTextBox_Text($"{viewers[cnt].name}님이 종료하셨습니다.\n");
                            clientSocket[cnt].Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(string.Format("InitSocket - Exception : {0}", ex.Message));
                    break;
                }
            }
        }

        private void Send_Receive_Data(int cnt, NetworkStream stream)           // Byte 정보 받는 함수
        {
            while (true)
            {
                if (viewers[cnt].room_num >= 1 && viewers[cnt].room_num <= 6)
                {
                    try
                    {
                        byte[] intbyte = new byte[1024];
                        stream.Read(intbyte, 0, intbyte.Length);
                        int sig = systems.ByteArrayToInt(intbyte);
                        //MessageBox.Show($"{sig}");
                        if (sig == 1)           // 메세지 부분
                        {
                            Delay(100);
                            int bytes = 0;
                            string msg = string.Empty;
                            byte[] strbyte = new byte[1024];
                            bytes = stream.Read(strbyte, 0, strbyte.Length);
                            msg = Encoding.Unicode.GetString(strbyte, 0, bytes);
                            msg = msg.Substring(0, msg.IndexOf("$"));
                            RichTextBox_Text($"{viewers[cnt].room_num}번방 {viewers[cnt].name}님의 채팅 : {msg}\n");
                            Send_Data(cnt, msg, stream, 1);
                        }
                        else if (sig == 2)      // 이미지 부분
                        {
                            RichTextBox_Text("이미지 정보\n");
                            Delay(100);
                            int bytes = 0;
                            byte[] viewbuf = new byte[1024];
                            MemoryStream memory = new MemoryStream();
                            byte[] sendbuf = new byte[1024];

                            while (true)
                            {
                                bytes = stream.Read(viewbuf, 0, viewbuf.Length);
                                memory.Write(viewbuf, 0, bytes);
                                if (stream.DataAvailable == false) break;
                            }

                            sendbuf = memory.ToArray();
                            Send_View(sendbuf, cnt);
                        }
                        else if (sig == 3)      // 음성 부분
                        {
                            RichTextBox_Text("음성 정보\n");
                        }
                        else if (sig == 4)      // 나가기
                        {
                            RichTextBox_Text($"{viewers[cnt].name}님이 {viewers[cnt].room_num}번방에서 나왔습니다.\n");
                            int bytes = 0;
                            string msg = string.Empty;
                            byte[] strbyte = new byte[1024];
                            bytes = stream.Read(strbyte, 0, strbyte.Length);
                            msg = Encoding.Unicode.GetString(strbyte, 0, bytes);
                            msg = msg.Substring(0, msg.IndexOf("$"));
                            if (viewers[cnt].mode == 1)
                            {
                                msg = "방송이 종료됬습니다.\n";
                                viewers[cnt].mode = 0;
                                systems.room_num[viewers[cnt].room_num - 1] = 0;
                                systems.viewers_num[viewers[cnt].room_num - 1] -= 1;
                                Send_Data(cnt, msg, stream, 6);
                            }
                            else
                            {
                                systems.viewers_num[viewers[cnt].room_num - 1] -= 1;
                                Send_Data(cnt, msg, stream, 5);
                            }
                            viewers[cnt].room_num = 0;
                            viewers[cnt].signal = 0;
                            break;
                        }
                        else if (sig == 5)
                        {
                            Delay(100);
                            int bytes = 0;
                            string msg = string.Empty;
                            byte[] strbyte = new byte[1024];
                            bytes = stream.Read(strbyte, 0, strbyte.Length);
                            msg = Encoding.Unicode.GetString(strbyte, 0, bytes);
                            msg = msg.Substring(0, msg.IndexOf("$"));
                            Send_Data(cnt, msg, stream, 4);
                        }
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine(string.Format("InitSocket - Exception : {0}", ex.Message));
                        break;
                    }
                }
            }
        }

        private void Send_Data(int cnt, string msg, NetworkStream stream, int n)
        {
            if (n == 1)
                msg = "1|" + $"{viewers[cnt].room_num}|" + viewers[cnt].name + "님의 채팅 : " + msg;        // 받은 메세지를 가지고 처음 sig를 추가해서 클라이언트에게 보내는 곳
            else if (n == 4 || n == 5)
                msg = $"{n}|" + $"{viewers[cnt].room_num}|" + viewers[cnt].name + msg;
            else if (n == 6)
                msg = "6|" + $"{viewers[cnt].room_num}|" + msg;

            byte[] strbyte = new byte[1024];
            strbyte = Encoding.Unicode.GetBytes(msg + "$");

            for (int i = 0; i < count; i++)                                                             // 모든 클라이언트에게 뿌림
            {
                NetworkStream streams = clientSocket[i].GetStream();
                streams.Write(strbyte, 0, strbyte.Length);
            }
        }

        private void Send_View(byte[] viewbuf, int cnt)
        {
            string msg = "2|$";
            byte[] Temp = new byte[1024];   //string
            Temp = Encoding.Unicode.GetBytes(msg);

            for (int i=0; i< count; i++)
            {
                
                if (viewers[cnt].room_num == viewers[i].room_num) // && viewers[cnt].mode != viewers[i].mode)
                {
                    NetworkStream streams = clientSocket[i].GetStream();        //string
                    streams.Write(Temp, 0, Temp.Length);
                    Delay(1);
                    streams = clientSocket[i].GetStream();      //뷰어
                    streams.Write(viewbuf, 0, viewbuf.Length);
                    //RichTextBox_Text($"{i} 뷰어 전송\n");
                }
            }
        }

        private void RichTextBox_Text(string msg)                                                       // 크로스 쓰레드 오류 방지용 함수
        {
            if (richTextBox1.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    richTextBox1.Text += msg;
                }));
            }
            else
            {
                richTextBox1.Text += msg;
            }
        }

        private static DateTime Delay(int MS)       //딜레이
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);
            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }
            return DateTime.Now;
        }

        private void tempServer_FormClosing(object sender, FormClosingEventArgs e)
        {
            for (int i = 0; i < count; i++)
                clientSocket[i].Close();

            server.Stop();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            this.richTextBox1.SelectionStart = richTextBox1.Text.Length;
            this.richTextBox1.ScrollToCaret();
        }
    }
}
