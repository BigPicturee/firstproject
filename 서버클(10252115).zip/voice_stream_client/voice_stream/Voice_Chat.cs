﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Threading;
using System.Drawing.Imaging;
using System.Net;
using System.Net.Sockets;

using voice_stream;

namespace voice_stream
{
    public partial class Voice_Chat : Form
    {
        //뷰어 변수
        private int mode = 0;
        private static Bitmap bmpScreen;
        //
        Thread recv_data;
        TcpClient clientSocket = new TcpClient();//소켓
        NetworkStream stream = default(NetworkStream);
        Voice_Stream loby;
        Mutex mutx = new Mutex();       // 뮤텍스 선언

        string message = string.Empty;

        public Voice_Chat()
        {
            InitializeComponent();
        }

        private void Voice_Chat_Load(object sender, EventArgs e)  //폼 로드 서버연결 시작
        {
            loby = (Voice_Stream)this.Owner;
            stream = loby.stream;
            clientSocket = loby.clientSocket;

            // stream = clientSocket.GetStream();//데이터를 보내고 받는데 사용되는 NetworkStream을 반환
            // message = "채팅 서버에 연결 되었습니다.";
            // DisplayText(message);

            //byte[] buffer = Encoding.Unicode.GetBytes("닉네임$");
            // stream.Write(buffer, 0, buffer.Length);
            // stream.Flush();

            //if (loby.viewers.mode == 1)      //스트리머
            //{
            //    Thread Viewthd = new Thread(() => Send_View());     //뷰어를 보낼 쓰레드 생성
            //    Viewthd.IsBackground = true;
            //    Viewthd.Start();
            //}

            Thread Started = new Thread(() => Threading_Start(loby));        // 정보를 계속 받을 쓰레드 생성
            Started.IsBackground = true;
            Started.Start();      // 쓰레드 시작

            InitSetting();
        }

        private void Threading_Start(Voice_Stream form)
        {
            while (true)
            {
                if (form.t_start == 1)
                {
                    recv_data = new Thread(() => Recevie_Data(form.stream));        // 정보를 계속 받을 쓰레드 생성
                    recv_data.IsBackground = true;
                    recv_data.Start();      // 쓰레드 시작

                    form.t_start = 0;

                    InitSetting();

                    //byte[] _intbyte = new byte[1024];
                    //_intbyte = loby.systems.IntToByteArray(5);
                    //stream.Write(_intbyte, 0, _intbyte.Length);
                    //stream.Flush();
                    //Delay(100);
                    //byte[] _strbyte = Encoding.Unicode.GetBytes("님이 들어왔습니다." + "$");
                    //stream.Write(_strbyte, 0, _strbyte.Length);
                    //stream.Flush();
                }
            }
        }

        private void New1_Close_Click(object sender, EventArgs e)
        {
            Voice_Stream Voice_Form = (Voice_Stream)this.Owner;
            
            DialogResult result = MessageBox.Show("나가시겠습니까?", "", MessageBoxButtons.OKCancel);

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                byte[] intbyte = new byte[1024];
                intbyte = Voice_Form.systems.IntToByteArray(4);
                Voice_Form.stream.Write(intbyte, 0, intbyte.Length);
                Delay(100);
                byte[] strbyte = Encoding.Unicode.GetBytes("님이 나갔습니다." + "$");
                loby.stream.Write(strbyte, 0, strbyte.Length);
                loby.stream.Flush();

                recv_data.Interrupt();
                recv_data.Abort();

                Exit();

                Hide();
            }
        }

        ////////////////////추휘선///////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Send_View()
        {
            loby = (Voice_Stream)this.Owner;

            byte[] viewbuf;
            try
            {
                while (true)
                {
                    byte[] intbyte = new byte[1024];
                    intbyte = loby.systems.IntToByteArray(2);       //뷰어: 2
                    loby.stream.Write(intbyte, 0, intbyte.Length);
                    loby.stream.Flush();
                    Delay(100);

                    CaptureScreen();

                    viewbuf = new byte[1024];
                    if(picCapture.InvokeRequired)
                    {
                        this.Invoke(new MethodInvoker(delegate ()
                        {
                            viewbuf = ImageToByteArray(picCapture.Image);
                        }));
                    }
                    else
                    {
                        viewbuf = ImageToByteArray(picCapture.Image);
                    }

                    stream.Write(viewbuf, 0, viewbuf.Length);
                    stream.Flush();

                    Delay(500);   //통신 딜레이
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void InitSetting()      //초기 설정
        {
            picMode.Image = Properties.Resources.Image_cursors;
            picMode.SizeMode = PictureBoxSizeMode.Zoom;
            picColor.BackColor = Color.Black;
            this.KeyPreview = true;
        }

        private void CaptureScreen()        //뷰어 캡쳐
        {
            bmpScreen = new Bitmap(600, 640);

            if(picCapture.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    using (Graphics g = Graphics.FromImage(bmpScreen))
                    {
                        g.CopyFromScreen(this.PointToScreen(new Point(picCapture.Bounds.X + 1, picCapture.Bounds.Y + 1)), new Point(0, 0), bmpScreen.Size, CopyPixelOperation.SourceCopy);
                        picCapture.Image = bmpScreen;
                    }
                }));
            }
            else
            {
                using (Graphics g = Graphics.FromImage(bmpScreen))
                {
                    g.CopyFromScreen(this.PointToScreen(new Point(picCapture.Bounds.X + 1, picCapture.Bounds.Y + 1)), new Point(0, 0), bmpScreen.Size, CopyPixelOperation.SourceCopy);
                    picCapture.Image = bmpScreen;
                }
            }
        }

        private void DrawMode()      //그리기 모드
        {
            CaptureScreen();
            picCapture.BringToFront();
        }

        private void New1_File_Click(object sender, EventArgs e)//파일 불러오기
        {
            OpenFile();
        }

        private void OpenFile()
        {
            OpenFileDialog openFile = new OpenFileDialog();

            openFile.Filter = "모든 파일(*.*) | *.*|PDF (* .pdf) | *.pdf; |이미지 (* .jpg, * .bmp, * .png) | *.jpg; *.bmp; *.png; ";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (openFile.FileName.EndsWith(".pdf"))     //PDF 
                    {
                        pdfView.BringToFront();
                        pdfView.LoadFile(openFile.FileName);
                    }

                    else if (openFile.FileName.EndsWith(".txt"))    //TXT        
                    {
                        RTB.BringToFront();
                        StreamReader objRead = new StreamReader(openFile.FileName);
                        RTB.Text = objRead.ReadToEnd();

                        objRead.Close();
                        objRead.Dispose();
                    }

                    else    // Image
                    {
                        PIC.BringToFront();
                        PIC.Image = Image.FromFile(@openFile.FileName);
                        PIC.SizeMode = PictureBoxSizeMode.Zoom;
                    }

                    txtPath.Text = openFile.FileName;
                }

                catch       //지원하지 않는 파일 형식
                {
                    MessageBox.Show("잘못된 파일 형식입니다.");
                }
            }
        }

        private Cursor GetImageCursor(Image image)      //커서 변경
        {
            int width = image.Width / 12;
            int height = image.Height / 12;

            Size resize = new Size(width, height);

            Bitmap bitmap = new Bitmap(image, resize);
            Graphics graphics = Graphics.FromImage(bitmap);
            IntPtr handle = bitmap.GetHicon();
            Cursor cursor = new Cursor(handle);
            return cursor;
        }

        private void picCapture_MouseMove(object sender, MouseEventArgs e)//그리기모드(선 긋기)
        {
            if (e.Button == MouseButtons.Left && this.Cursor != Cursors.Default)
            {
                Point curPoint = picCapture.PointToClient(new Point(Control.MousePosition.X, Control.MousePosition.Y));

                Pen p = new Pen(picColor.BackColor);
                p.Width = 8;

                Graphics g = Graphics.FromImage(picCapture.Image);
                g.DrawEllipse(p, curPoint.X, curPoint.Y, p.Width, p.Width);
                picCapture.Image = picCapture.Image;

                p.Dispose();
                g.Dispose();
            }
        }

        private void picColor_Click(object sender, EventArgs e)//펜 색상 변경
        {
            ChangeColor();
        }

        private void picMode_Click(object sender, EventArgs e)//모드 변경
        {
            ChangeMode();
        }

        private void Voice_Chat_KeyDown(object sender, KeyEventArgs e)//(모드 변경)(단축키)
        {
            if (e.Control && e.KeyCode == (Keys.Q))
            {
                ChangeMode();
            }

            else if (e.Control && e.KeyCode == (Keys.W))
            {
                ChangeColor();
            }
        }

        private void ChangeColor()
        {
            ColorDialog colorlog = new ColorDialog();
            if (colorlog.ShowDialog() == DialogResult.OK)
            {
                picColor.BackColor = colorlog.Color;
            }
        }

        private void ChangeMode()
        {
            if (mode == 0)       //일반모드 -> 그리기모드
            {
                mode = 1;

                this.Cursor = GetImageCursor(Properties.Resources.Image_Pen);

                picMode.Image = Properties.Resources.Image_Pen;
                picMode.SizeMode = PictureBoxSizeMode.Zoom;

                DrawMode();
            }
            else if (mode == 1)      //그리기모드 -> 일반모드
            {
                mode = 0;

                picCapture.SendToBack();

                this.Cursor = Cursors.Default;

                picMode.Image = Properties.Resources.Image_cursors;
                picMode.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private byte[] ImageToByteArray(System.Drawing.Image image)      //이미지=>배열 변환
        {
            MemoryStream ms = new MemoryStream();
            image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            return ms.ToArray();
        }

        private static DateTime Delay(int MS)       //딜레이 
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);
            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }
            return DateTime.Now;
        }

        private void picCapture_Image(Image img)
        {
            if(picCapture.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    picCapture.Image = img;
                }));
            }
            else
            {
                picCapture.Image = img;
            }
        }

        private void chkStreamer_CheckedChanged(object sender, EventArgs e)
        {

            if (loby.viewers.mode == 1)      //스트리머
            {
                chkStreamer.Checked = true;
                Thread Viewthd = new Thread(() => Send_View());     //뷰어를 보낼 쓰레드 생성
                Viewthd.IsBackground = true;
                Viewthd.Start();
            }
        }

        private Image ByteArrayToImage(byte[] byteArrayIn)       //바이트=>이미지 (lock : 한번에 한 스레드씩 접근)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = new Bitmap(Image.FromStream(ms));
            return returnImage;
        }
        ///////////////////////////////한솔 (Message)////////////////////////////

        /////////////////////////////Message invoke처리
        private void DisplayText(string text) //Server에 메시지 출력
        {
            //하나의 Form을 다른 thread에서 접근하게 될 경우에 기존의 Form과 충돌이 날 수 있다.
            //invoke를 사용하여 실행하려고 하는 메소드의 대리자를 실행
            if (textBox1.InvokeRequired)
            {
                textBox1.BeginInvoke(new MethodInvoker(delegate
                {
                    textBox1.AppendText(text + Environment.NewLine);
                }));

            }
            else
                textBox1.AppendText(text + Environment.NewLine);
        }

        private void Voice_Chat_FormClosing(object sender, FormClosingEventArgs e)  //폼 닫을 때 프로세스 및 쓰레드 종료
        {
            //byte[] buffer = Encoding.Unicode.GetBytes("leavechat" + "$");
            //stream.Write(buffer, 0, buffer.Length); //채팅방 나갔다고 서버에 보냄
            //stream.Flush(); //이 스트림에 대해 모든 버퍼를 지우고 버퍼링된 데이터가 내부 디바이스에 쓰여지도록
            Application.ExitThread();  //쓰레드 종료
            Environment.Exit(0); //프로세스 종료,종료코드 반환
        }

        private void Send_Message_Click(object sender, EventArgs e)  //메세지 보내기
        {
            this.ActiveControl = textBox;

            loby = (Voice_Stream)this.Owner;

            byte[] intbyte = new byte[1024];
            intbyte = loby.systems.IntToByteArray(1);
            loby.stream.Write(intbyte, 0, intbyte.Length);
            loby.stream.Flush();
            Delay(100);
            byte[] strbyte = Encoding.Unicode.GetBytes(textBox.Text + "$");
            loby.stream.Write(strbyte, 0, strbyte.Length);
            loby.stream.Flush();
            textBox.Clear();
        }

        private void Recevie_Data(NetworkStream stream)                 // 메세지 받는 쓰레드 함수
        {
            loby = (Voice_Stream)this.Owner;

            while (true)
            {
                if (loby.viewers.mode == 0)
                    stream.Flush();
                //
                int bytes = 0;
                string msg = string.Empty;
                byte[] strbyte = new byte[1024];
                bytes = stream.Read(strbyte, 0, strbyte.Length);
                msg = Encoding.Unicode.GetString(strbyte, 0, bytes);
                msg = msg.Substring(0, msg.IndexOf("$"));               // 무조건 처음 받을 때는 string으로 받음
                string[] signal = msg.Split('|');                       // 받은 msg 문자열을 '|(shift + \)'을 기준으로 잘라서 signal에 넣기
                if (signal[0] == "1")                                    // 메세지 부분
                {
                    if ($"{loby.viewers.room_num}" == signal[1])       // 방번호와 안맞으면 textBox에 출력이 안됨
                        DisplayText(signal[2]);
                }
                else if (signal[0] == "2")                              // 이미지 부분
                {
                    int nbytes = 0;
                    byte[] viewbuf = new byte[1024];
                    MemoryStream memory = new MemoryStream();
                    byte[] viewbuf2 = new byte[1024];

                    while (true)
                    {
                        nbytes = stream.Read(viewbuf, 0, viewbuf.Length);
                        memory.Write(viewbuf, 0, nbytes);
                        if (stream.DataAvailable == false) break;
                    }

                    viewbuf2 = memory.ToArray();

                    if (loby.viewers.mode == 0)      //시청자
                    {
                        picCapture_Image(ByteArrayToImage(viewbuf2));      //바이트 -> 이미지 //loby.systems.byteArrayToImage(original)
                    }
                }
                else if (signal[0] == "3")                              // 음성 부분
                {
                    textBox1.Text += "음성 정보\n";
                }
                else if (signal[0] == "4" && signal[0] == "5")
                {
                    if ($"{loby.viewers.room_num}" == signal[1])       // 방번호와 안맞으면 textBox에 출력이 안됨
                        DisplayText(signal[2]);
                }
                else if (signal[0] == "6")
                {
                    if ($"{loby.viewers.room_num}" == signal[1])       // 방번호와 안맞으면 textBox에 출력이 안됨
                    {
                        DisplayText(signal[2]);
                        MessageBox.Show("방송이 종료됬습니다.");
                    }
                }
            }
        }

        private void Exit()
        {
            loby = (Voice_Stream)this.Owner;

            if (loby.viewers.mode == 1)
            {
                loby.viewers.room_num = 0;
                loby.viewers.mode = 0;
            }
            loby.viewers.signal = 0;

            textBox1.Clear();
        }

        //private void TextBox_Text(string msg)                           // 크로스 쓰레드 오류 방지용 함수
        //{
        //    if (textBox1.InvokeRequired)
        //    {
        //        this.Invoke(new MethodInvoker(delegate ()
        //        {
        //            textBox1.AppendText(msg);//Text += msg;
        //        }));
        //    }
        //    else
        //    {
        //        textBox1.AppendText(msg);//Text += msg;
        //    }
        //}

        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.ActiveControl = textBox;

                loby = (Voice_Stream)this.Owner;

                byte[] intbyte = new byte[1024];
                intbyte = loby.systems.IntToByteArray(1);
                loby.stream.Write(intbyte, 0, intbyte.Length);
                loby.stream.Flush();
                Delay(100);
                byte[] strbyte = Encoding.Unicode.GetBytes(textBox.Text + "$");
                loby.stream.Write(strbyte, 0, strbyte.Length);
                loby.stream.Flush();
                textBox.Clear();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.ActiveControl = textBox;
            }
        }
 
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
