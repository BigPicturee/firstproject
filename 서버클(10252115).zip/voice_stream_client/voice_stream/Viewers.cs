﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace voice_stream
{
    public class Viewers
    {
        public int room_num = 0;    // 클라이언트가 들어간 방번호
        public int mode = 0;        // 시청자 = 0, 스트리머 = 1
        public int signal = 0;      // 로비 = 0, 방 = 1
        public string[] chat = new string[100]; // 채팅을 저장 할 배열
        public string name;     // 닉네임
    }
}
